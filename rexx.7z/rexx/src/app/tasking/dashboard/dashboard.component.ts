import { Component } from '@angular/core';
import { select, NgRedux } from '@angular-redux/store'; 
  
import { IAppState } from 'src/app/store/store';
import { CLEAR_TODOS } from '../actions';

@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.css']
})
export class DashboardComponent  {
  @select(s => s.tasking.lastUpdate) lastUpdate;
  @select(s => s.tasking.todos) todos;

  constructor(private ngRedux: NgRedux<IAppState>) {
   }

  deleteAll() {  
       this.ngRedux.dispatch({type: CLEAR_TODOS}); 
    }  
}
