import { Component } from '@angular/core';
import { NgRedux, select } from '@angular-redux/store';
 
import { TOGGLE_TODO, ADD_TODO, REMOVE_TODO } from '../actions';
import { IAppState } from 'src/app/store/store';

@Component({
  selector: 'app-todo',
  templateUrl: './todo.component.html',
  styleUrls: ['./todo.component.css']
})
export class TodoComponent  {
  itemName: string;
  @select(s => s.tasking.todos) todos;

  constructor(private ngRedux: NgRedux<IAppState>) {
  }

  add() { 
    if (this.itemName && this.itemName.trim()){
       this.ngRedux.dispatch({type: ADD_TODO, title: this.itemName.trim() });
       this.itemName = null; 
    }
      
  } 

  toggleTodo(todo) {
    this.ngRedux.dispatch({ type: TOGGLE_TODO, id: todo.id });
  }
  
  delete(todo){
    this.ngRedux.dispatch({type: REMOVE_TODO, id: todo.id});
  }
}
