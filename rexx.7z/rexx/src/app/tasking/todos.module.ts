import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { NgReduxModule } from '@angular-redux/store';

import { TodoComponent } from './todo/todo.component';
import { DashboardComponent } from './dashboard/dashboard.component';
import { TodoService } from './service/todo.service'; 
import { FormsModule } from '@angular/forms';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    NgReduxModule
  ],
  declarations: [
    TodoComponent,
    DashboardComponent
  ],
  exports: [
    TodoComponent,
    DashboardComponent
  ],
  providers: [TodoService],
})
export class TodosModule { }
